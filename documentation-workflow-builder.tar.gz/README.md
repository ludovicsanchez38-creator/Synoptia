# 🤖 Synoptia Workflow Builder

Un agent IA qui génère automatiquement des workflows n8n à partir de demandes en français naturel.

## 🎯 Qu'est-ce que c'est ?

Imagine que tu puisses dire : *"Je veux envoyer un email tous les lundis matin"* et que ton ordinateur crée automatiquement tout le système pour le faire. C'est exactement ça !

Synoptia Workflow Builder transforme tes idées en français en workflows n8n fonctionnels, comme par magie ✨

## 🚀 Installation rapide

### 1. Télécharge le projet
```bash
git clone <ton-repo>
cd synoptia-workflow-builder
```

### 2. Installe les dépendances
```bash
npm install
```

### 3. Configure tes clés
```bash
cp .env.example .env
```

Puis édite le fichier `.env` avec tes vraies clés :
```env
# Ta clé OpenAI (obligatoire)
OPENAI_API_KEY=sk-ton-api-key-openai

# Ton n8n (optionnel pour tester)
N8N_API_URL=https://n8n.synoptia.fr/api/v1
N8N_API_KEY=ta-cle-n8n
```

### 4. Lance l'agent
```bash
npm start
```

Ouvre http://localhost:3000 dans ton navigateur 🎉

## 💡 Comment ça marche ?

### Interface Simple
1. **Écris ta demande** en français naturel
2. **Clique sur "Créer"**
3. **C'est fini !** 🎉

### Exemples de demandes

- *"Je veux envoyer un email quotidien à 9h"*
- *"Synchroniser mes données CRM avec mon tableau de bord"*
- *"Envoyer une notification quand quelqu'un remplit mon formulaire"*
- *"Traiter automatiquement les fichiers dans mon dossier"*
- *"Créer un rapport hebdomadaire et l'envoyer par email"*

## 🔧 Utilisation avancée

### API REST

#### Créer un workflow
```bash
curl -X POST http://localhost:3000/api/create-workflow \
  -H "Content-Type: application/json" \
  -d '{
    "request": "Je veux envoyer un email quotidien",
    "autoExecute": true
  }'
```

#### Obtenir des infos sur l'agent
```bash
curl http://localhost:3000/api/agent-info
```

### Mode développement
```bash
npm run dev  # Auto-reload quand tu modifies le code
```

### Tests
```bash
npm test
```

## 📋 Que peut faire l'agent ?

### Types de workflows supportés
- ✅ **Envoi d'emails** automatiques
- ✅ **Notifications** push/SMS
- ✅ **Traitement de données**
- ✅ **Synchronisation** entre services
- ✅ **Planification** d'actions
- ✅ **Webhooks** et triggers

### Intégrations disponibles
- 📧 Email (SMTP, Gmail, Outlook)
- 🔗 HTTP/API REST
- ⏰ Planificateur (cron)
- 📁 Traitement de fichiers
- 🔄 Webhooks

## 🛠 Architecture

```
src/
├── index.js           # Point d'entrée
├── mcp-server.js      # Serveur MCP principal
├── workflow-generator.js # Génération des workflows
├── n8n-api.js         # Client API n8n
public/
├── index.html         # Interface utilisateur
config/
├── .env.example       # Configuration
```

### Comment ça fonctionne techniquement ?

1. **Réception** : L'utilisateur décrit son besoin
2. **Analyse** : OpenAI GPT-4 analyse et structure la demande
3. **Génération** : Création du JSON du workflow n8n
4. **Déploiement** : Envoi automatique vers l'instance n8n
5. **Confirmation** : Retour utilisateur avec lien direct

## 🔒 Sécurité

- ✅ Les clés API ne sont jamais exposées
- ✅ Validation des entrées utilisateur
- ✅ Limitation des types de workflows
- ✅ Gestion des erreurs sécurisée

## 🐛 Résolution de problèmes

### L'agent ne démarre pas
- Vérifie que ta clé OpenAI est valide
- Assure-toi que le port 3000 est libre

### Pas de déploiement automatique
- Vérifie tes credentials n8n dans `.env`
- Teste la connexion à ton instance n8n

### Workflow généré bizarre
- Sois plus précis dans ta demande
- Utilise les exemples fournis comme base

## 📞 Support

- 📧 Email : ludo@synoptia.fr
- 🐛 Bugs : [GitHub Issues](https://github.com/synoptia/workflow-builder/issues)
- 💬 Questions : [Discord Synoptia](https://discord.gg/synoptia)

## 🎯 Roadmap

### V1.1 (Prochaine)
- [ ] Templates de workflows prédéfinis
- [ ] Export/Import de workflows
- [ ] Interface de monitoring

### V1.2 (Plus tard)
- [ ] Support de plus d'intégrations
- [ ] Workflows conditionnels avancés
- [ ] Tableau de bord analytics

## 📜 Licence

MIT - Fais-en ce que tu veux ! 🚀

---

*Fait avec ❤️ par Ludo pour Synoptia*